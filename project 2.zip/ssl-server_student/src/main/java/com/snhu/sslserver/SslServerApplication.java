package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@RestController

@SpringBootApplication 
public class SslServerApplication {


 public static void main(String[] args) {
     SpringApplication.run(SslServerApplication.class, args);
 }

 @RequestMapping("/hash")
 public String generateChecksum(@RequestParam(value="name", defaultValue="Christian Parker") String name) {
     String uniqueDataString = "Developer: " + name + " | Data-Payload-ID: " + java.util.UUID.randomUUID().toString();
     try {
         MessageDigest digest = MessageDigest.getInstance("SHA-256");
         byte[] hashBytes = digest.digest(uniqueDataString.getBytes(StandardCharsets.UTF_8));
         
         StringBuilder hexString = new StringBuilder();
         for (byte b : hashBytes) {
             String hex = Integer.toHexString(0xff & b);
             if (hex.length() == 1) hexString.append('0');
             hexString.append(hex);
         }
         String checksum = hexString.toString();
         
         return "<h3>Practices for Secure Software Report - Checksum Verification</h3>" +
                "<p><b>Name:</b> " + name + "</p>" +
                "<p><b>Unique Data String:</b> " + uniqueDataString + "</p>" +
                "<p><b>SHA-256 Checksum:</b> <font color='green'><code>" + checksum + "</code></font></p>";
     } catch (NoSuchAlgorithmException e) {
         return "Error: Cryptographic hash algorithm SHA-256 not found. " + e.getMessage();
     }
 }
}